# 客户测算交付包

入口：[测算报告](report.client.md)；[测算依据](report.evidence.md)。图片和必要依据在本目录内，可整体复制或解压后阅读，无需原仓库及Skill。

报告针对2026-10-20确认的DeepSeek-V4.1-Flash、8K/1K平均长度、60路突发条件，固定Prefill8张＋Decode8张布局。16张是明确假设下的预算候选，并非全局最少卡数或实测达标结论。

`sources/`包含必要的固定模型/推理实现快照及清单、结构分组摘要和硬件说明；`.source.txt`是原始Markdown文档的内容快照，原文的延伸链接未全部打包。完整权重和实测性能数据未包含。

可选复算：Python 3运行`calculate.py`，再运行`render.py`。数值计算只用标准库和本地`tools/`，不联网。重新生成PNG还需Windows、PowerShell 7和System.Drawing；不重绘时可直接使用随包图片。文件摘要见`package-manifest.json`，原始来源修订及SHA见sources清单。
