# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from collections.abc import Iterable
from dataclasses import dataclass, replace

import torch
from typing_extensions import Self
from vllm.config import VllmConfig
from vllm.utils.math_utils import cdiv
from vllm.utils.torch_utils import get_dtype_size
from vllm.v1.core.single_type_kv_cache_manager import FullAttentionManager, SlidingWindowManager
from vllm.v1.kv_cache_interface import (
    CircularBufferSpec,
    FullAttentionSpec,
    KVCacheSpec,
    MambaSpec,
    MLAAttentionSpec,
    SlidingWindowMLASpec,
    SlidingWindowSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.kv_cache_spec_registry import KVCacheSpecRegistry


def get_kv_cache_compression_ratio(kv_cache_spec: KVCacheSpec) -> int:
    """Return the MLA compression ratio across vLLM cache-spec APIs."""
    return kv_cache_spec.tokens_per_state


def get_storage_block_size(kv_cache_spec: KVCacheSpec) -> int:
    """Return the physical token rows represented by one scheduler block."""
    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        storage_block_sizes = {get_storage_block_size(spec) for spec in kv_cache_spec.kv_cache_specs.values()}
        assert len(storage_block_sizes) == 1, "All specs in one KV cache group must use the same storage block size."
        return storage_block_sizes.pop()
    # vLLM #53906 added an optional MLA storage-view override. It is not
    # Ascend's derived number of physical rows per logical block.
    if isinstance(kv_cache_spec, AscendMLAAttentionSpec):
        return kv_cache_spec.block_size // kv_cache_spec.tokens_per_state
    if isinstance(kv_cache_spec, MLAAttentionSpec):
        storage_block_size = kv_cache_spec.storage_block_size
        return kv_cache_spec.block_size if storage_block_size is None else storage_block_size
    return getattr(kv_cache_spec, "storage_block_size", kv_cache_spec.block_size)


def is_circular_kv_cache_spec(kv_cache_spec: KVCacheSpec) -> bool:
    """Resolve the fixed-block addressing capability through grouped specs."""
    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        specs = tuple(kv_cache_spec.kv_cache_specs.values())
        return bool(specs) and all(is_circular_kv_cache_spec(spec) for spec in specs)
    return isinstance(kv_cache_spec, CircularBufferSpec) or getattr(kv_cache_spec, "is_circular", False)


def is_prefix_cacheable(kv_cache_spec: KVCacheSpec) -> bool:
    """Resolve cacheability through uniform wrappers.

    ``prefix_cacheable`` is the upstream API on the lanes that define it; the
    release lane predates it, so an unset attribute means cacheable.
    """
    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        return all(is_prefix_cacheable(spec) for spec in kv_cache_spec.kv_cache_specs.values())
    return bool(getattr(kv_cache_spec, "prefix_cacheable", True)) and bool(
        getattr(kv_cache_spec, "participates_in_prefix_caching", True)
    )


def requires_padded_page_layout(kv_cache_specs: Iterable[KVCacheSpec]) -> bool:
    """Whether state caches advance by a padded page size shared with attention.

    Ascend mixed pools can bind one physical page to both an attention cache and a
    recurrent state cache. The attention side of such a pool is addressed by an explicit
    physical block stride (``indexes_kv_by_block_stride``) and the state caches are
    padded to that same page size, so every view over the shared page has to advance by
    the padded page size: otherwise a state update for one scheduler block ID would land
    in the pages owned by another block ID.

    The capability belongs to the pool rather than to a single spec, because hybrid
    models also pad Mamba pages through ``cache_config.mamba_page_size_padded`` while
    keeping the packed contiguous state layout, so padding alone does not require this
    layout.
    """
    specs = list(kv_cache_specs)
    state_specs = [spec for spec in specs if isinstance(spec, MambaSpec)]
    if not state_specs:
        return False
    if not any(getattr(spec, "page_size_padded", None) is not None for spec in state_specs):
        return False
    return any(getattr(spec, "indexes_kv_by_block_stride", False) for spec in specs)


def supports_component_major_mla_pd(vllm_config: VllmConfig) -> bool:
    """Whether PD transfer can preserve a component-major MLA cache layout.

    A component-major MLA page packs NoPE and RoPE into one physical slot:
    ``[all NoPE][all RoPE][padding]``.  MooncakeV2 pull connectors transfer
    that page as one raw block when the published base address, block length,
    and block stride describe the complete slot.  Other connectors still use
    the legacy separate NoPE/RoPE protocol.

    Without PD, local layout selection is unrestricted. With supported PD,
    both endpoints must agree on the page layout: raw transfers carry no
    metadata distinguishing component-major from token-fused FlashMLA pages.
    This helper identifies connector support, not cross-endpoint agreement.
    """
    kv_transfer_config = vllm_config.kv_transfer_config
    if kv_transfer_config is None:
        return True

    # Connectors loaded through a custom module path are not identified by the
    # registry name, so conservatively fall back to the legacy layout.
    if getattr(kv_transfer_config, "kv_connector_module_path", None) is not None:
        return False

    return getattr(kv_transfer_config, "kv_connector", None) in {
        "MooncakeConnectorV2",
        "MooncakePullConnector",
    }


@dataclass(frozen=True, kw_only=True)
class AscendMLAAttentionSpec(MLAAttentionSpec):
    """MLA cache spec with Ascend-specific layout metadata.

    For SFA, this spec describes only the main MLA cache. The indexer K
    tensor, its quantization scale, and DCP replication are described by a
    separate :class:`AscendSFAIndexerCacheSpec`.
    """

    # Per-rank query heads used by FlashMLA layout selection. Auxiliary MLA
    # caches without query heads use the one-latent-head cache contract.
    num_heads: int = 1
    scale_dim: int = 0
    scale_dtype: torch.dtype = torch.int8
    # Sparse C8 changes the main cache into one packed byte tensor. Keep that
    # main-cache property here; indexer-specific C8 properties belong to the
    # indexer spec.
    cache_sparse_sfa_c8: bool = False
    cache_sparse_sfa_turboquant: bool = False
    store_on_host: bool = False
    # Ascend kernels consume padded pages through an explicit physical block
    # stride. vLLM main removed this field from AttentionSpec, but it remains
    # part of the Ascend runner/backend contract.
    indexes_kv_by_block_stride: bool = False

    @property
    def uses_packed_sfa_main_cache(self) -> bool:
        """Whether the SFA main cache is stored in one packed tensor."""
        return self.cache_sparse_sfa_c8 or self.cache_sparse_sfa_turboquant

    @property
    def supports_single_raw_backing(self) -> bool:
        """Whether this geometry can be exposed from one raw MLA backing."""
        return (
            get_kv_cache_compression_ratio(self) == 1
            and self.model_version is None
            and not self.indexes_kv_by_block_stride
            and not self.cache_sparse_sfa_c8
        )

    @property
    def real_page_size_bytes(self) -> int:
        return (
            get_storage_block_size(self)
            * self.num_kv_heads
            * (self.head_size * get_dtype_size(self.dtype) + self.scale_dim * get_dtype_size(self.scale_dtype))
        )

    @property
    def unpadded_page_size_bytes(self) -> int:
        return self.real_page_size_bytes

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        # Uniformity probes may include indexer specs, which share the upstream
        # MLA base class but do not have the main cache's layout metadata.
        assert all(isinstance(spec, AscendMLAAttentionSpec) for spec in specs), (
            "All attention layers in the same KV cache group must be AscendMLAAttentionSpec."
        )
        ascend_layouts = {
            (
                spec.scale_dim,
                spec.num_heads,
                spec.scale_dtype,
                spec.cache_sparse_sfa_c8,
                spec.cache_sparse_sfa_turboquant,
                spec.store_on_host,
                spec.alignment,
                get_kv_cache_compression_ratio(spec),
                spec.indexes_kv_by_block_stride,
            )
            for spec in specs
        }
        assert len(ascend_layouts) == 1, (
            "All attention layers in the same KV cache group must use the same Ascend KV cache layout."
        )
        non_causal_multi_token_decode_set = set(spec.non_causal_multi_token_decode for spec in specs)
        assert len(non_causal_multi_token_decode_set) == 1, (
            "Causal target layers and non-causal multi-token draft layers must use separate KV cache groups."
        )
        first_spec = specs[0]
        merged = super().merge(specs)
        return replace(
            merged,
            scale_dim=first_spec.scale_dim,
            num_heads=first_spec.num_heads,
            scale_dtype=first_spec.scale_dtype,
            alignment=first_spec.alignment,
            cache_sparse_sfa_c8=first_spec.cache_sparse_sfa_c8,
            cache_sparse_sfa_turboquant=first_spec.cache_sparse_sfa_turboquant,
            store_on_host=first_spec.store_on_host,
            indexes_kv_by_block_stride=first_spec.indexes_kv_by_block_stride,
        )

    def max_memory_usage_bytes(self, vllm_config: VllmConfig) -> int:
        max_model_len = vllm_config.model_config.max_model_len
        dcp_world_size = vllm_config.parallel_config.decode_context_parallel_size
        # Note(hc): each dcp rank only need save
        # (max_model_len//dcp_world_size) tokens locally.
        if dcp_world_size > 1:
            max_model_len = cdiv(max_model_len, dcp_world_size)
        return cdiv(max_model_len, self.block_size) * self.page_size_bytes


@dataclass(frozen=True, kw_only=True)
class AscendSFAIndexerCacheSpec(MLAAttentionSpec):
    """KV cache spec for SFA indexer K/scale cache.

    The scheduler should treat this as a full-attention-compatible cache so it
    can share block ids with the MLA cache in the same UniformType group. The
    model runner still allocates it as an independent physical cache tensor.
    """

    scale_dim: int = 0
    scale_dtype: torch.dtype = torch.int8
    cache_sparse_li_c8: bool = False
    cache_sparse_li_c4: bool = False
    cache_dtype_str: str | None = None
    sfa_dcp_replicated_indexer_size: int = 1

    @property
    def page_size_bytes(self) -> int:
        return self.real_page_size_bytes

    @property
    def real_page_size_bytes(self) -> int:
        num_heads_per_page = self.block_size * self.num_kv_heads
        return (
            self.sfa_dcp_replicated_indexer_size
            * num_heads_per_page
            * (self.head_size * get_dtype_size(self.dtype) + self.scale_dim * get_dtype_size(self.scale_dtype))
        )

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, AscendSFAIndexerCacheSpec) for spec in specs), (
            "All attention layers in the same KV cache group must be AscendSFAIndexerCacheSpec."
        )
        cache_dtype_str_set = set(spec.cache_dtype_str for spec in specs)
        dtype_set = set(spec.dtype for spec in specs)
        scale_dim_set = set(spec.scale_dim for spec in specs)
        scale_dtype_set = set(spec.scale_dtype for spec in specs)
        cache_sparse_li_c8_set = set(spec.cache_sparse_li_c8 for spec in specs)
        cache_sparse_li_c4_set = set(spec.cache_sparse_li_c4 for spec in specs)
        sfa_dcp_replicated_indexer_size_set = set(spec.sfa_dcp_replicated_indexer_size for spec in specs)
        assert (
            len(cache_dtype_str_set) == 1
            and len(dtype_set) == 1
            and len(scale_dim_set) == 1
            and len(scale_dtype_set) == 1
            and len(cache_sparse_li_c8_set) == 1
            and len(cache_sparse_li_c4_set) == 1
            and len(sfa_dcp_replicated_indexer_size_set) == 1
        ), (
            "All SFA indexer cache layers in the same KV cache group must use "
            "the same dtype, scale layout, quantization method, LI quant flags "
            "and DCP replication size."
        )
        return cls(
            block_size=specs[0].block_size,
            num_kv_heads=specs[0].num_kv_heads,
            head_size=specs[0].head_size,
            dtype=dtype_set.pop(),
            cache_dtype_str=cache_dtype_str_set.pop(),
            scale_dim=scale_dim_set.pop(),
            scale_dtype=scale_dtype_set.pop(),
            cache_sparse_li_c8=cache_sparse_li_c8_set.pop(),
            cache_sparse_li_c4=cache_sparse_li_c4_set.pop(),
            sfa_dcp_replicated_indexer_size=sfa_dcp_replicated_indexer_size_set.pop(),
        )


@dataclass(frozen=True, kw_only=True)
class AscendSlidingWindowMLASpec(SlidingWindowMLASpec):
    """Sliding window attention with MLA cache format."""

    cache_dtype_str: str | None = None
    # DeepseekV4-only: see MLAAttentionSpec.model_version.
    alignment: int | None = None  # Default to None for no padding.
    compress_ratio: int = 1
    model_version: str | None = None
    indexes_kv_by_block_stride: bool = False

    def __post_init__(self):
        pass

    @property
    def storage_block_size(self) -> int:
        return self.block_size // self.compress_ratio

    @property
    def real_page_size_bytes(self) -> int:
        return self.storage_block_size * self.num_kv_heads * self.head_size * get_dtype_size(self.dtype)

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, AscendSlidingWindowMLASpec) for spec in specs), (
            "All attention layers in the same KV cache group must be AscendSlidingWindowMLASpec."
        )
        cache_dtype_str_set = set(spec.cache_dtype_str for spec in specs)
        compress_ratio_set = set(spec.compress_ratio for spec in specs)
        model_version_set = set(spec.model_version for spec in specs)
        sliding_window_set = set(spec.sliding_window for spec in specs)
        assert (
            len(cache_dtype_str_set) == 1
            and len(compress_ratio_set) == 1
            and len(model_version_set) == 1
            and len(sliding_window_set) == 1
        ), (
            "All attention layers in the same KV cache group must use the same "
            "quantization method, compress ratio, model version and sliding "
            "window size."
        )
        return cls(
            block_size=specs[0].block_size,
            num_kv_heads=specs[0].num_kv_heads,
            head_size=specs[0].head_size,
            dtype=specs[0].dtype,
            page_size_padded=specs[0].page_size_padded,
            sliding_window=sliding_window_set.pop(),
            cache_dtype_str=cache_dtype_str_set.pop(),
            compress_ratio=compress_ratio_set.pop(),
            model_version=model_version_set.pop(),
        )


@dataclass(frozen=True, kw_only=True)
class AscendIndexerKPoolTailSpec(SlidingWindowSpec):
    """One fixed FP32 ``[ring_capacity, 2 * head_size]`` page per request.

    ``block_size`` is the physical ring capacity; ``compress_ratio`` defines
    pool boundaries independently. The dedicated manager never slides or grows.
    """

    compress_ratio: int
    model_version: str = "glm5_next"
    cache_role: str = "indexer_tail"
    indexes_kv_by_block_stride: bool = True

    @property
    def is_circular(self) -> bool:
        return True

    @property
    def prefix_cacheable(self) -> bool:
        return False

    @property
    def unpadded_page_size_bytes(self) -> int:
        # The tail stores a fixed K/gate pair; the parent handles page padding.
        return 2 * self.block_size * self.head_size * get_dtype_size(self.dtype)

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.dtype != torch.float32:
            raise ValueError(f"Indexer K-pool tail must use FP32, got {self.dtype}.")
        if self.num_kv_heads != 1 or self.head_size <= 0:
            raise ValueError("Indexer K-pool tail requires one K/gate pair with positive head size.")
        if self.compress_ratio <= 1 or self.block_size < self.compress_ratio:
            raise ValueError("Tail ring capacity must be at least the compression ratio, which must exceed one.")
        if self.sliding_window != self.compress_ratio:
            raise ValueError("Tail sliding_window describes the logical pool size and must equal compress_ratio.")

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, cls) for spec in specs)
        return super().merge(specs)

    def max_memory_usage_bytes(self, vllm_config: VllmConfig) -> int:
        del vllm_config
        return self.page_size_bytes

    def max_admission_blocks_per_request(self, max_in_flight_tokens: int, max_model_len: int) -> int:
        return 1

    def max_num_blocks_per_req(self, vllm_config: VllmConfig, max_len: int) -> int:
        return 1

    def is_uniform_with_collection(self, kv_cache_specs: dict[str, KVCacheSpec]) -> bool:
        return all(
            isinstance(spec, AscendIndexerKPoolTailSpec)
            and spec.block_size == self.block_size
            and spec.compress_ratio == self.compress_ratio
            for spec in kv_cache_specs.values()
        )


@dataclass(frozen=True, kw_only=True)
class AscendCircularBufferSpec(CircularBufferSpec):
    """Circular state whose physical pages participate in Ascend KV zeroing."""

    def is_uniform_with_collection(self, kv_cache_specs: dict[str, KVCacheSpec]) -> bool:
        return all(isinstance(spec, AscendCircularBufferSpec) for spec in kv_cache_specs.values())


def register_ascend_kv_cache_specs() -> None:
    from vllm_ascend.core.single_type_kv_cache_manager import AscendCircularBufferManager
    from vllm_ascend.models.glm5next.kv_cache import KpoolTailManager

    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendCircularBufferSpec,
        manager_class=AscendCircularBufferManager,
        uniform_type_base_spec=AscendCircularBufferSpec,
    )

    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendMLAAttentionSpec,
        manager_class=FullAttentionManager,
        uniform_type_base_spec=FullAttentionSpec,
    )
    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendSFAIndexerCacheSpec,
        manager_class=FullAttentionManager,
        uniform_type_base_spec=FullAttentionSpec,
    )
    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendSlidingWindowMLASpec,
        manager_class=SlidingWindowManager,
        uniform_type_base_spec=SlidingWindowMLASpec,
    )

    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendIndexerKPoolTailSpec,
        manager_class=KpoolTailManager,
        uniform_type_base_spec=AscendIndexerKPoolTailSpec,
    )
